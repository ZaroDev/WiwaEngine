﻿using Wiwa;

namespace WiwaApp
{
    [Component]
    public struct TankComponent
    {
        public float Velocity;
        public float RotateVelocity;
    }
    class TankController : Behaviour
    {
        void Awake()
        {

        }

        void Init()
        {

        }

        void Update()
        {
            ref TankComponent tank = ref GetComponent<TankComponent>();
            ref Transform3D transform = ref GetComponent<Transform3D>();
            float transAmount = tank.Velocity * Time.DeltaTime();
            float rotAmount = tank.RotateVelocity * Time.DeltaTime();


            if (Input.IsKeyDown(KeyCode.W))
            {
                //Console.WriteLine("Pa lante");
                transform.LocalPosition += Math.CalculateForward(ref transform) * transAmount;
            }
            else if (Input.IsKeyDown(KeyCode.S))
            {
                //Console.WriteLine("Pa tra");
                transform.LocalPosition -= Math.CalculateForward(ref transform) * transAmount;
            }
            if (Input.IsKeyDown(KeyCode.A))
            {
                //Console.WriteLine("Pa izquielda");
                transform.LocalRotation.z += rotAmount;
            }
            else if (Input.IsKeyDown(KeyCode.D))
            {
                //Console.WriteLine("Pa delecha");
                transform.LocalRotation.z -= rotAmount;
            }

        }

    }
}
