namespace Wiwa
{
    [Component]
    public struct TankTurretComp
    {
        public Transform3D camera;
        public Transform3D spawnPoint;
        public float rotationY;
        public float velX;
        public float fireInterval;
        public float nextFire;
    }
    public class TankTurret : Behaviour
    {
        //Called the first frame
        void Awake()
        {
        }
        //Called after Awake()
        void Init()
        {
        }
        //Called every frame
        void Update()
        {

            ref TankTurretComp tank = ref GetComponent<TankTurretComp>();
            CameraControls(ref tank);
            tank.fireInterval += Time.DeltaTime();
            if (Input.IsMouseKeyDown(0) && tank.nextFire < tank.fireInterval)
            {
                tank.nextFire = 0;
                SpawnBullet();
            }
        }

        private void SpawnBullet()
        {
            //Instantiate(bulletPrefab, spawnPoint.position, spawnPoint.rotation);
            //EntityId ent = CreateEntity();
        }
        private void CameraControls(ref TankTurretComp tank)
        {
            ref Transform3D transform = ref GetComponent<Transform3D>();
            tank.rotationY -= Input.GetMouseXDelta() * tank.velX * Time.DeltaTime();

            //Console.WriteLine($"X {Input.GetMouseXDelta()} Y {Input.GetMouseYDelta()}");
            transform.LocalRotation = new Vector3(transform.LocalRotation.x, transform.LocalRotation.y, tank.rotationY);
            //tank.camera.LookAt(tank.tankTower);
        }
    }
}
